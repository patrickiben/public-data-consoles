# Resilience Telemetry snapshot refresh — runbook

Tools (keep them outside the repo):

- `refresh_snapshot.py`: roundtrip / selftest / fetch / rebuild. Needs stdlib plus `xlrd` for Shiller.
- `verify.mjs`: headless Chromium. It blocks all network, so the page shows only the embedded snapshot. It writes a JSON dump and screenshots.
- `carddiff.py`: line diff of every card's text between two `verify.mjs` dumps. These are the figures to re-quote in `roadmap.html` and `wiki.html`.
- `appendtest.py`: offline test that truncates the snapshot and rebuilds it forward from fake API responses.

The target file is the `withDays`/`DAYS` version of `consoles/resilience-telemetry/index.html`, on branch `claude/awesome-heisenberg-tkzyiv` (PR #2, not merged yet). Tested against its head 75f3b46.

## Hosts that must be reachable

- `query1.finance.yahoo.com`
- `api.binance.us`
- `api.frankfurter.dev`
- `fred.stlouisfed.org`
- Shiller: `www.econ.yale.edu`, falling back to `shillerdata.com` plus the host its `ie_data.xls` link points to (usually `img1.wsimg.com`)

No API keys are used. No relay or proxy services are used either (r.jina.ai and allorigins are not needed).

## Steps

```sh
T=/path/to/these/tools; W=/path/to/workdir; IDX=consoles/resilience-telemetry/index.html
python3 -m venv $W/venv && $W/venv/bin/pip install xlrd==2.0.1
PY="$W/venv/bin/python -I"

$PY $T/refresh_snapshot.py roundtrip $IDX               # must print "roundtrip OK … identical"
$PY $T/refresh_snapshot.py selftest $IDX --workdir=$W   # must print "selftest OK"
node $T/verify.mjs $IDX $W/out before                   # before screenshots + before.json

mkdir $W/raw && $PY $T/refresh_snapshot.py fetch $IDX $W/raw         # raw responses only; lists failures
$PY $T/refresh_snapshot.py rebuild $IDX $W/raw $W/new.html           # exit 1 if any source failed
less $W/new.html.report.md                                           # per-series old→new end, overlap checks
node $T/verify.mjs $W/new.html $W/out after                          # as-of pill, data health, JS errors, cross-asset end
python3 -I $T/carddiff.py $W/out/before.json $W/out/after.json       # every figure that moved
cp $W/new.html $IDX                                                  # then update roadmap.html / wiki.html
```

Options:

- `fetch --window=roll`: rolling windows (Yahoo 10 years, crypto 1000 days) instead of the default `keep` (each series keeps its existing start date).
- `rebuild --cap=YYYY-MM-DD`: cut every market series at one common date.

For a local run without `/opt/node22`, install Playwright with `npm i playwright && npx playwright install chromium`, then set `PLAYWRIGHT_MODULE=playwright`.

## What the rebuild checks (per series, on the overlap with the old snapshot)

- **Yahoo adjusted vs unadjusted.** The rebuild compares both `close` and `adjclose` against the oldest year of the existing data and refuses the series if the expected field isn't the closer one. Batch A (SPY…UUP plus ^VIX) uses unadjusted close at 2 dp. The later batches (XLV…CORN, VGK…IBND) use dividend-adjusted close at 4 dp; expect many "changed" values there, because each new dividend rescales the adjusted history.
- **In-progress bars dropped.** That means a Yahoo bar whose session hasn't closed and a Binance candle whose `closeTime` is in the future. The old snapshot's last OHLC bar, SPY 744.284 on 2026-06-22, was such an intraday quote.
- **FRED.** Every series keeps its start date and frequency. ICSA is divided by 1000. T10Y2Y, T10Y3M, DFII10 and T10YIE keep every 5th valid observation, anchored on the last old date. The rebuild also checks that plain every-5th sampling from 2007 reproduces the old dates. The BAML spreads keep their pre-window history, since FRED only serves the last 3 years of ICE data. A frequency change aborts that series.
- **Frankfurter.** Fetched in 90-day chunks. The rebuild aborts if the result looks down-sampled.
- **Shiller VAL.** `capeMean` is the median of the CAPE series, to 1 dp. `cur` is rewritten only if the same formulas give back the existing `cur` at 2024-09 from the new file. `reg` is refit only if a candidate specification reproduces the existing a/b/r2/rsd exactly; otherwise it is left unchanged and the report says so.
