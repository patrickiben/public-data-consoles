// Headless check of the resilience-telemetry console on its EMBEDDED snapshot only.
// usage: node verify.mjs <index.html> <outdir> [label]
// Every http(s) request is aborted, so the live feeds fail and the page shows the snapshot as baked in.
// Writes <outdir>/<label>.json (as-of, data health, JS errors, cross-asset end date, every card's text)
// and full-page screenshots per tab.
import { createRequire } from 'module';
import fs from 'fs';
import path from 'path';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/opt/node22/lib/node_modules/playwright');

const [file, outdir, label = 'run'] = process.argv.slice(2);
fs.mkdirSync(outdir, { recursive: true });
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
const pageErrors = [], consoleErrors = [], blocked = new Set();
page.on('pageerror', e => pageErrors.push(String(e.stack || e)));
page.on('console', m => { if (m.type() === 'error') consoleErrors.push(m.text()); });
await page.route('**/*', r => {
  const u = r.request().url();
  if (u.startsWith('file:') || u.startsWith('data:')) return r.continue();
  blocked.add(new URL(u).host); return r.abort();
});
await page.goto('file://' + path.resolve(file));
await page.waitForFunction(() => (document.querySelector('#feeds')?.innerText || '').includes('markets as of'), null, { timeout: 60000 });
// let the deferred computations settle: wait until the page text stops changing
let prev = -1;
for (let i = 0; i < 40; i++) {
  const n = await page.evaluate(() => document.body.innerText.length);
  if (n === prev) break; prev = n; await page.waitForTimeout(750);
}
const facts = await page.evaluate(() => {
  const A = asOfInfo();
  const common = alignedReturns(null, 1e9).dates;
  const ends = Object.fromEntries(ASSET_IDS.map(id => [id, msToDateStr(dayToMs(STORE[id].dayk[STORE[id].dayk.length - 1]))]));
  return {
    pill: document.querySelector('#asoftx')?.innerText,
    dataHealth: document.querySelector('#feeds')?.innerText,
    regime: document.querySelector('#regimeline, .regime')?.innerText || null,
    asOf: A, crossAssetLastCommon: msToDateStr(dayToMs(common[common.length - 1])), crossAssetDays: common.length,
    seriesEnds: ends, feedStatus,
    macroLast: Object.fromEntries(Object.entries(MACRO).map(([k, m]) => [k, msToDateStr(dayToMs(m.d[m.d.length - 1]))])),
    capeCur: VAL.cur, nSeries: ASSET_IDS.length,
  };
});
const cards = {};
for (const pg of ['diag', 'pred', 'risk']) {
  await page.click(`#pagetabs button[data-pg="${pg}"]`);
  await page.waitForTimeout(1500);
  await page.screenshot({ path: path.join(outdir, `${label}-${pg}.png`), fullPage: true });
  Object.assign(cards, await page.evaluate(pg => {
    const o = {};
    for (const c of document.querySelectorAll('.card')) {
      if (!c.offsetParent) continue;
      const h = c.querySelector('h2'); if (!h) continue;
      o[`${pg} · ${h.innerText.split('\n')[0].trim()}`] = c.innerText;
    }
    return o;
  }, pg));
}
await page.click('#pagetabs button[data-pg="diag"]');
const head = await page.$('header') || await page.$('body');
await head.screenshot({ path: path.join(outdir, `${label}-header.png`) });
const health = await page.$('#feeds');
if (health) { const card = await health.evaluateHandle(e => e.closest('.card') || e); await card.asElement().screenshot({ path: path.join(outdir, `${label}-datahealth.png`) }); }
await browser.close();
const result = { label, file, ...facts, pageErrors, consoleErrors: consoleErrors.filter(t => !/ERR_FAILED|Failed to load resource/.test(t)),
  networkErrorsIgnored: consoleErrors.length, blockedHosts: [...blocked], cards };
fs.writeFileSync(path.join(outdir, `${label}.json`), JSON.stringify(result, null, 1));
const ok = !pageErrors.length && !result.consoleErrors.length && facts.crossAssetLastCommon === facts.asOf.date;
console.log(JSON.stringify({ label, pill: facts.pill, asOf: facts.asOf.date, newest: facts.asOf.newest,
  crossAssetLastCommon: facts.crossAssetLastCommon, pageErrors: pageErrors.length, consoleErrors: result.consoleErrors.length,
  blockedHosts: result.blockedHosts, cards: Object.keys(cards).length, ok }, null, 1));
console.log(facts.dataHealth);
process.exit(ok ? 0 : 1);
