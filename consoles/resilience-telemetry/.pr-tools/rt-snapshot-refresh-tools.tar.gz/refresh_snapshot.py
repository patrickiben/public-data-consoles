#!/usr/bin/env python3
"""Refresh the embedded offline snapshot of consoles/resilience-telemetry/index.html.

Keyless public sources only. Standard library, plus `xlrd` for Shiller's .xls.

  roundtrip INDEX                 parse DAYS/SNAP/MACRO/OHLC/VAL and re-emit them; must be byte-identical
  selftest  INDEX                 offline: write the current snapshot out as fake API responses, rebuild
                                  from them, and expect the original back (exercises every parser + merge)
  fetch     INDEX RAWDIR          download raw responses into a NEW empty RAWDIR (nothing is parsed here)
  rebuild   INDEX RAWDIR OUT      merge RAWDIR into INDEX's constants, write OUT and OUT.report.md

Run the data-reading steps with `python3 -I` and keep RAWDIR apart from this script.

Rules recovered from the existing snapshot (see `rules` below; the rebuild re-checks each on overlap):
  * day numbers count days since 2000-01-01 UTC; DAYS holds every distinct SNAP/OHLC date axis,
    delta-encoded, in order of first appearance
  * Yahoo batch A (SPY..UUP + ^VIX): unadjusted (split-adjusted) close, rounded to 2 dp
  * Yahoo batches B/C (XLV..CORN, VGK..IBND): dividend-adjusted close, rounded to 4 dp
  * OHLC (SPY/QQQ/IWM/GLD/TLT): unadjusted open/close, 2 dp (equal to SNAP closes on shared dates)
  * Binance.US daily kline close, 2 dp;  Frankfurter base-USD rates as served
  * FRED: raw values (ICSA / 1000); T10Y2Y/T10Y3M/DFII10/T10YIE keep every 5th valid observation;
    every series keeps its existing start date (older points FRED no longer serves are kept)
  * VAL: CAPE monthly from 1881-01 (2 dp); capeMean = median(cape) to 1 dp;
    cur/reg are only rewritten if the formulas reproduce the existing values from the new file first
"""
import csv, datetime as dt, io, json, math, os, re, statistics, sys, time, urllib.error, urllib.parse, urllib.request

EPOCH = dt.date(2000, 1, 1)
EPOCH_MS = 946684800000
UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36'

def day_of(date): return (date - EPOCH).days
def date_of(day): return EPOCH + dt.timedelta(days=day)
def iso(day): return date_of(day).isoformat()

# --------------------------------------------------------------------------- the five constants

LINE_RE = {
    'DAYS':  re.compile(r'^const DAYS=(\[\[.*?\]\])(\.map\(.*)$'),
    'SNAP':  re.compile(r'^const SNAP = withDays\((\{.*\})\);$'),
    'MACRO': re.compile(r'^const MACRO = (\{.*\});$'),
    'OHLC':  re.compile(r'^const OHLC = withDays\((\{.*\})\);$'),
    'VAL':   re.compile(r'^const VAL = (\{.*\});$'),
}

STR_TOKEN = re.compile(r'"(?:[^"\\]|\\.)*"')

def dumps(o, spelling=None):
    s = json.dumps(o, separators=(',', ':'), ensure_ascii=True)
    if not spelling: return s
    return STR_TOKEN.sub(lambda m: spelling.get(json.loads(m.group(0)), m.group(0)), s)

class Page:
    def __init__(self, text):
        self.lines = text.split('\n')
        self.at, found = {}, {}
        for i, line in enumerate(self.lines):
            for name, rx in LINE_RE.items():
                m = rx.match(line)
                if m:
                    if name in found: sys.exit(f'{name} defined twice')
                    self.at[name], found[name] = i, m
        # strings keep the spelling they had (the page mixes \uXXXX escapes and raw UTF-8)
        self.spelling = {}
        for i in self.at.values():
            for tok in STR_TOKEN.findall(self.lines[i]): self.spelling.setdefault(json.loads(tok), tok)
        missing = set(LINE_RE) - set(found)
        if missing: sys.exit(f'constants not found: {sorted(missing)}')
        self.days_suffix = found['DAYS'].group(2)
        days = []
        for a in json.loads(found['DAYS'].group(1)):
            out, x = [], 0
            for i, v in enumerate(a):
                x = x + v if i else v
                out.append(x)
            days.append(out)
        self.snap = json.loads(found['SNAP'].group(1))
        self.ohlc = json.loads(found['OHLC'].group(1))
        self.macro = json.loads(found['MACRO'].group(1))
        self.val = json.loads(found['VAL'].group(1))
        for obj in (self.snap, self.ohlc):        # withDays(): numeric d -> DAYS[d]
            for v in obj.values():
                if isinstance(v['d'], int): v['d'] = list(days[v['d']])

    def render(self):
        axes, index = [], {}
        def axis(d):
            key = tuple(d)
            if key not in index:
                index[key] = len(axes)
                axes.append(d)
            return index[key]
        def enc(obj):
            return {k: {kk: (axis(vv) if kk == 'd' else vv) for kk, vv in v.items()} for k, v in obj.items()}
        snap, ohlc = enc(self.snap), enc(self.ohlc)
        delta = [[a[0]] + [b - c for b, c in zip(a[1:], a[:-1])] for a in axes]
        lines = list(self.lines)
        lines[self.at['DAYS']] = 'const DAYS=' + dumps(delta) + self.days_suffix
        sp = self.spelling
        lines[self.at['SNAP']] = 'const SNAP = withDays(' + dumps(snap, sp) + ');'
        lines[self.at['MACRO']] = 'const MACRO = ' + dumps(self.macro, sp) + ';'
        lines[self.at['OHLC']] = 'const OHLC = withDays(' + dumps(ohlc, sp) + ');'
        lines[self.at['VAL']] = 'const VAL = ' + dumps(self.val, sp) + ';'
        return '\n'.join(lines)

def read_page(path):
    with open(path, encoding='utf-8', newline='') as f: return f.read()

# --------------------------------------------------------------------------- source rules

BATCH_A = ['SPY', 'QQQ', 'IWM', 'XLF', 'XLK', 'XLE', 'AAPL', 'MSFT', 'NVDA', 'TLT', 'LQD', 'HYG', 'DBC',
           'USO', 'GLD', 'VIX', 'UUP']
BATCH_BC = ['XLV', 'XLI', 'XLU', 'XLP', 'EEM', 'EFA', 'SHV', 'VCIT', 'IGV', 'CORN', 'VGK', 'EWG', 'EWU',
            'EWJ', 'MCHI', 'INDA', 'EWY', 'EWT', 'EWZ', 'EWC', 'EWW', 'ACWX', 'BWX', 'BNDX', 'EMB', 'EMLC', 'IBND']
YAHOO_MODE = {**{k: ('close', 2) for k in BATCH_A}, **{k: ('adjclose', 4) for k in BATCH_BC}}
YAHOO_SYMBOL = {'VIX': '^VIX'}
CRYPTO = {'BTC': 'BTCUSDT', 'ETH': 'ETHUSDT', 'SOL': 'SOLUSDT'}
FX = {'USDJPY': 'JPY', 'USDCHF': 'CHF', 'USDAUD': 'AUD', 'USDEUR': 'EUR'}
FRED_SCALE = {'ICSA': 1000}                  # value = FRED value / scale
FRED_EVERY5 = {'T10Y2Y', 'T10Y3M', 'DFII10', 'T10YIE'}

def check_rules(page):
    ids = list(page.snap)
    want = set(YAHOO_MODE) | set(CRYPTO) | set(FX)
    if set(ids) != want: sys.exit(f'SNAP ids changed: extra {set(ids) - want}, missing {want - set(ids)}')
    for k in ids:
        cls = page.snap[k]['cls']
        if (k in CRYPTO) != (cls == 'crypto') or (k in FX) != (cls == 'fx'): sys.exit(f'{k}: unexpected cls {cls}')

def window_start(old_start, last_needed, policy, years=10, days=None):
    if policy == 'keep': return old_start
    if days is not None: return max(old_start, last_needed - (days - 1))
    t = date_of(last_needed)
    return max(old_start, day_of(t.replace(year=t.year - years)))

# --------------------------------------------------------------------------- fetch

class Fetcher:
    def __init__(self, rawdir):
        self.rawdir, self.log, self.dead = rawdir, [], {}

    def get(self, url, rel, headers=None, tries=4):
        host = urllib.parse.urlsplit(url).hostname
        if host in self.dead:
            self.log.append({'url': url, 'file': rel, 'ok': False, 'error': f'skipped: {host} already refused ({self.dead[host]})'})
            return None
        err = None
        for attempt in range(tries):
            try:
                req = urllib.request.Request(url, headers={'User-Agent': UA, **(headers or {})})
                with urllib.request.urlopen(req, timeout=60) as r:
                    body = r.read()
                path = os.path.join(self.rawdir, rel)
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, 'wb') as f: f.write(body)
                self.log.append({'url': url, 'file': rel, 'ok': True, 'bytes': len(body)})
                return body
            except urllib.error.HTTPError as e:
                err = f'HTTP {e.code}'
                if e.code not in (429, 500, 502, 503, 504): break
            except (urllib.error.URLError, OSError) as e:
                err = str(getattr(e, 'reason', e))
                if 'Tunnel connection failed' in err or 'Name or service not known' in err or 'resolve' in err:
                    self.dead[host] = err       # egress policy / DNS: never retry, never route around
                    break
            time.sleep(2 ** (attempt + 1))
        self.log.append({'url': url, 'file': rel, 'ok': False, 'error': err})
        return None

def cmd_fetch(index, rawdir, policy='keep'):
    if os.path.exists(rawdir) and os.listdir(rawdir): sys.exit(f'{rawdir} must be a new, empty directory')
    os.makedirs(rawdir, exist_ok=True)
    page = Page(read_page(index)); check_rules(page)
    F = Fetcher(rawdir)
    now = dt.datetime.now(dt.timezone.utc)
    today = day_of(now.date())
    p2 = int(now.timestamp())
    # Yahoo: one request per symbol covers SNAP and OHLC
    for k in YAHOO_MODE:
        start = min(page.snap[k]['d'][0], page.ohlc[k]['d'][0] if k in page.ohlc else 10**9)
        start = window_start(start, today, policy)
        p1 = (start - 7) * 86400 + EPOCH_MS // 1000
        sym = YAHOO_SYMBOL.get(k, k)
        F.get(f'https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(sym)}'
              f'?period1={p1}&period2={p2}&interval=1d&includeAdjustedClose=true&events=div%2Csplit',
              f'yahoo/{k}.json')
    # Binance.US: paginate 1000 daily klines at a time
    for k, pair in CRYPTO.items():
        start = window_start(page.snap[k]['d'][0], today - 1, policy, days=1000)
        t, n = EPOCH_MS + start * 86400000, 0
        while True:
            body = F.get(f'https://api.binance.us/api/v3/klines?symbol={pair}&interval=1d&startTime={t}&limit=1000',
                         f'binance/{pair}.{n:02d}.json')
            if body is None: break
            rows = json.loads(body)
            if len(rows) < 1000: break
            t, n = rows[-1][0] + 86400000, n + 1
    # Frankfurter: 90-day chunks so long ranges cannot come back down-sampled
    s = page.snap['USDEUR']['d'][0]
    while s <= today:
        e = min(s + 89, today)
        F.get(f'https://api.frankfurter.dev/v1/{iso(s)}..{iso(e)}?base=USD&symbols=EUR,JPY,CHF,AUD',
              f'frankfurter/{iso(s)}.json')
        s = e + 1
    # FRED: keyless graph CSV, full history (the rebuild trims to each series' start)
    for k in page.macro:
        F.get(f'https://fred.stlouisfed.org/graph/fredgraph.csv?id={k}', f'fred/{k}.csv')
    # Shiller: the Yale URL, else the xls linked from shillerdata.com
    if F.get('http://www.econ.yale.edu/~shiller/data/ie_data.xls', 'shiller/ie_data.xls', tries=2) is None:
        home = F.get('https://shillerdata.com/', 'shiller/home.html', tries=2)
        if home:
            m = re.search(rb'href="([^"]*ie_data\.xls[^"]*)"', home)
            if m:
                url = m.group(1).decode()
                F.get(('https:' + url) if url.startswith('//') else url, 'shiller/ie_data.xls', tries=2)
    meta = {'fetched_at': now.isoformat(), 'window': policy, 'requests': F.log}
    with open(os.path.join(rawdir, 'meta.json'), 'w') as f: json.dump(meta, f, indent=1)
    bad = [r for r in F.log if not r['ok']]
    print(f'{len(F.log) - len(bad)} ok, {len(bad)} failed')
    for r in bad: print('  FAIL', r['url'], '->', r['error'])
    for h, e in F.dead.items(): print(f'  host refused: {h} ({e})')

# --------------------------------------------------------------------------- parse raw responses

def load(rawdir, rel, mode='rb'):
    p = os.path.join(rawdir, rel)
    if not os.path.exists(p): return None
    with open(p, mode) as f: return f.read()

def parse_yahoo(body, fetched_ms):
    j = json.loads(body)
    if j.get('chart', {}).get('error'): raise ValueError(j['chart']['error'])
    r = j['chart']['result'][0]
    ts = r.get('timestamp') or []
    q = r['indicators']['quote'][0]
    adj = (r['indicators'].get('adjclose') or [{}])[0].get('adjclose') or [None] * len(ts)
    off = r['meta'].get('gmtoffset', 0)
    rows = {}
    for i, t in enumerate(ts):
        if q['close'][i] is None: continue
        rows[(t + off) // 86400 - EPOCH_MS // 86400000] = (q['open'][i], q['close'][i], adj[i])
    # drop an in-progress bar: the current regular session has not ended at fetch time
    reg = (r['meta'].get('currentTradingPeriod') or {}).get('regular')
    if reg and rows and fetched_ms < reg['end'] * 1000:
        live_day = (reg['start'] + off) // 86400 - EPOCH_MS // 86400000
        rows.pop(live_day, None)
    return dict(sorted(rows.items()))

def parse_binance(bodies, fetched_ms):
    rows = {}
    for b in bodies:
        for k in json.loads(b):
            if k[6] >= fetched_ms: continue            # candle still open
            rows[(k[0] - EPOCH_MS) // 86400000] = float(k[4])
    return dict(sorted(rows.items()))

def parse_frankfurter(bodies):
    rows = {}
    for b in bodies:
        j = json.loads(b)
        if j.get('base') != 'USD': raise ValueError(f"base {j.get('base')}")
        for d, r in j['rates'].items(): rows[day_of(dt.date.fromisoformat(d))] = r
    return dict(sorted(rows.items()))

def parse_fred_csv(body, sid):
    rd = csv.reader(io.StringIO(body.decode('utf-8-sig')))
    head = next(rd)
    if len(head) != 2 or head[1] != sid: raise ValueError(f'unexpected header {head}')
    out = []
    for row in rd:
        if len(row) != 2 or row[1] in ('', '.'): continue
        out.append((day_of(dt.date.fromisoformat(row[0])), float(row[1])))
    return out

# --------------------------------------------------------------------------- merge helpers

class Report:
    def __init__(self): self.rows, self.notes, self.errors = [], [], []
    def row(self, *a): self.rows.append(a)
    def note(self, s): self.notes.append(s); print('  note:', s)
    def error(self, s): self.errors.append(s); print('  ERROR:', s)

def overlap_stats(old_d, old_v, new, tol):
    """new: {day: value}. Compare on old's date range."""
    lo, hi = old_d[0], old_d[-1]
    om = dict(zip(old_d, old_v))
    both = [d for d in old_d if d in new]
    diff = [d for d in both if abs(new[d] - om[d]) > tol]
    worst = max((abs(new[d] / om[d] - 1) for d in both if om[d]), default=0.0)
    missing = [d for d in old_d if d not in new and d >= min(new, default=hi + 1)]
    extra = [d for d in new if lo <= d <= hi and d not in om]
    return {'n': len(both), 'diff': diff, 'worst': worst, 'missing': missing, 'extra': extra}

def splice(old_d, old_v, new, start, clip=None):
    """Old points before the first new day are kept (history the source no longer serves);
    from there on the new data wins. Everything before `start` is dropped."""
    first = min(new) if new else old_d[-1] + 1
    pts = {d: v for d, v in zip(old_d, old_v) if start <= d < first}
    pts.update({d: v for d, v in new.items() if d >= start})
    if clip: pts = {d: v for d, v in pts.items() if clip[0] <= d <= clip[1]}
    ks = sorted(pts)
    return ks, [pts[k] for k in ks]

def fmt_stats(st):
    s = f"overlap {st['n']}, changed {len(st['diff'])}, max |Δ| {st['worst']*100:.3g}%"
    if st['missing']: s += f", {len(st['missing'])} old dates gone ({iso(st['missing'][0])}…)"
    if st['extra']: s += f", {len(st['extra'])} new dates inside old range ({iso(st['extra'][0])}…)"
    return s

# --------------------------------------------------------------------------- rebuild

def cmd_rebuild(index, rawdir, out, policy=None, cap=None, clip_existing=False, quiet=False):
    page = Page(read_page(index)); check_rules(page)
    meta = json.loads(load(rawdir, 'meta.json'))
    fetched = dt.datetime.fromisoformat(meta['fetched_at'])
    fetched_ms = int(fetched.timestamp() * 1000)
    today = day_of(fetched.date())
    policy = policy or meta.get('window', 'keep')
    cap = day_of(dt.date.fromisoformat(cap)) if cap else None
    R = Report()
    old_end = {k: v['d'][-1] for k, v in page.snap.items()}
    clipr = (lambda d: (d[0], d[-1])) if clip_existing else (lambda d: None)

    def capped(new):
        return {d: v for d, v in new.items() if cap is None or d <= cap}

    # ---- Yahoo
    for k, (field, dec) in YAHOO_MODE.items():
        body = load(rawdir, f'yahoo/{k}.json')
        if body is None: R.error(f'Yahoo {k}: no data, series left as is'); continue
        try: rows = parse_yahoo(body, fetched_ms)
        except Exception as e: R.error(f'Yahoo {k}: {e!r}, series left as is'); continue
        s = page.snap[k]
        # which Yahoo field reproduces the existing closes?  (decides adjusted vs unadjusted)
        err = {}
        for f, fi in (('close', 1), ('adjclose', 2)):
            vals = {d: round(r[fi], dec) for d, r in rows.items() if r[fi] is not None}
            older = [d for d in s['d'] if d in vals][:250]   # oldest year: adjustment shows most there
            err[f] = statistics.median(abs(vals[d] / c - 1) for d, c in zip(s['d'], s['c']) if d in older) if older else 9
        best = min(err, key=err.get)
        if best != field:
            R.error(f'Yahoo {k}: expected {field} but {best} matches the snapshot better '
                    f'(median rel err close {err["close"]:.2e}, adjclose {err["adjclose"]:.2e}); series left as is')
            continue
        fi = 1 if field == 'close' else 2
        new = capped({d: round(r[fi], dec) for d, r in rows.items() if r[fi] is not None})
        st = overlap_stats(s['d'], s['c'], new, 0.5 * 10 ** -dec + 1e-9)
        start = window_start(s['d'][0], max(new), policy)
        if min(new) > s['d'][0] + 7 and start == s['d'][0]:
            R.note(f'Yahoo {k}: history now starts {iso(min(new))}, snapshot started {iso(s["d"][0])}'
                   + (' — adjusted series, prefix NOT spliced' if field == 'adjclose' else ' — old prefix kept'))
            if field == 'adjclose': start = min(new)
        s['d'], s['c'] = splice(s['d'], s['c'], new, start, clipr(s['d']))
        R.row('Yahoo', k, f'{field} {dec}dp', iso(old_end[k]), iso(s['d'][-1]), len(s['d']), fmt_stats(st))
        if k in page.ohlc:
            o = page.ohlc[k]
            no = capped({d: round(r[0], 2) for d, r in rows.items() if r[0] is not None})
            nc = capped({d: round(r[1], 2) for d, r in rows.items() if r[0] is not None})
            sto = overlap_stats(o['d'], o['o'], no, 0.0051)
            stc = overlap_stats(o['d'], o['c'], nc, 0.0051)
            ostart = window_start(o['d'][0], max(nc), policy)
            od_old = o['d'][-1]
            d1, ov = splice(o['d'], o['o'], no, ostart, clipr(o['d']))
            d2, cv = splice(o['d'], o['c'], nc, ostart, clipr(o['d']))
            if d1 != d2: R.error(f'OHLC {k}: open/close dates disagree'); continue
            o['d'], o['o'], o['c'] = d1, ov, cv
            R.row('Yahoo OHLC', k, 'open/close 2dp', iso(od_old), iso(o['d'][-1]), len(o['d']),
                  f"open: {fmt_stats(sto)}; close: {fmt_stats(stc)}")

    # ---- Binance.US
    for k, pair in CRYPTO.items():
        bodies = [load(rawdir, f'binance/{f}') for f in sorted(os.listdir(os.path.join(rawdir, 'binance')))
                  if f.startswith(pair + '.')] if os.path.isdir(os.path.join(rawdir, 'binance')) else []
        if not bodies: R.error(f'Binance {pair}: no data, series left as is'); continue
        try: rows = parse_binance(bodies, fetched_ms)
        except Exception as e: R.error(f'Binance {pair}: {e!r}'); continue
        s = page.snap[k]
        new = capped({d: round(v, 2) for d, v in rows.items()})
        st = overlap_stats(s['d'], s['c'], new, 0.0051)
        start = window_start(s['d'][0], max(new), policy, days=1000)
        s['d'], s['c'] = splice(s['d'], s['c'], new, start, clipr(s['d']))
        R.row('Binance.US', k, pair, iso(old_end[k]), iso(s['d'][-1]), len(s['d']), fmt_stats(st))

    # ---- Frankfurter
    fdir = os.path.join(rawdir, 'frankfurter')
    bodies = [load(rawdir, f'frankfurter/{f}') for f in sorted(os.listdir(fdir))] if os.path.isdir(fdir) else []
    try: fx = parse_frankfurter(bodies) if bodies else {}
    except Exception as e: R.error(f'Frankfurter: {e!r}'); fx = {}
    if not fx: R.error('Frankfurter: no data, FX left as is')
    else:
        span = (max(fx) - min(fx)) / 365.25
        if len(fx) < 200 * span: R.error(f'Frankfurter: only {len(fx)} dates over {span:.1f} years — down-sampled?')
        for k, code in FX.items():
            s = page.snap[k]
            new = capped({d: r[code] for d, r in fx.items() if code in r})
            st = overlap_stats(s['d'], s['c'], new, 1e-12)
            s['d'], s['c'] = splice(s['d'], s['c'], new, s['d'][0], clipr(s['d']))
            R.row('Frankfurter', k, code, iso(old_end[k]), iso(s['d'][-1]), len(s['d']), fmt_stats(st))

    # ---- FRED
    for k, m in page.macro.items():
        body = load(rawdir, f'fred/{k}.csv')
        if body is None: R.error(f'FRED {k}: no data, series left as is'); continue
        try: obs = parse_fred_csv(body, k)
        except Exception as e: R.error(f'FRED {k}: {e!r}, series left as is'); continue
        scale = FRED_SCALE.get(k, 1)
        obs = [(d, v / scale if scale != 1 else v) for d, v in obs if d >= m['d'][0]]
        if not obs: R.error(f'FRED {k}: nothing on/after {iso(m["d"][0])}'); continue
        old_last = m['d'][-1]
        extra = ''
        if k in FRED_EVERY5:
            days_ = [d for d, _ in obs]
            if days_[::5][:len(m['d'])] == m['d']: extra = 'every-5th sampling reproduces all old dates; '
            else: R.note(f'FRED {k}: every-5th sampling from the start no longer reproduces the old dates — anchoring on the last old date')
            vals = dict(obs)
            if old_last not in vals:
                R.error(f'FRED {k}: last snapshot date {iso(old_last)} missing from FRED; series left as is'); continue
            i = days_.index(old_last)
            keep = {d: vals.get(d, v) for d, v in zip(m['d'], m['v'])}
            keep.update({d: vals[d] for d in days_[i + 5::5]})
            new = keep
        else:
            new = dict(obs)
        st = overlap_stats(m['d'], m['v'], new, 1e-9)
        if k in FRED_EVERY5: st['missing'] = []        # by construction
        med_old = statistics.median(b - a for a, b in zip(m['d'], m['d'][1:]))
        nd = sorted(new)
        med_new = statistics.median(b - a for a, b in zip(nd, nd[1:]))
        if abs(med_new - med_old) > 0.5 * med_old: R.error(f'FRED {k}: frequency changed ({med_old}d → {med_new}d steps)'); continue
        m['d'], m['v'] = splice(m['d'], m['v'], new, m['d'][0], clipr(m['d']))
        R.row('FRED', k, m['unit'], iso(old_last), iso(m['d'][-1]), len(m['d']), extra + fmt_stats(st))

    # ---- Shiller
    xls = load(rawdir, 'shiller/ie_data.xls')
    if xls is None: R.error('Shiller: no ie_data.xls, VAL left as is')
    elif clip_existing: R.note('Shiller: skipped in --clip-existing mode')
    else: rebuild_val(page, xls, R)

    html = page.render()
    with open(out, 'w', encoding='utf-8', newline='') as f: f.write(html)
    write_report(page, R, meta, out + '.report.md', policy, cap)
    if not quiet:
        print(f'wrote {out} ({len(html):,} bytes) and {out}.report.md; {len(R.errors)} error(s), {len(R.notes)} note(s)')
    return page, R

# --------------------------------------------------------------------------- Shiller / VAL

def shiller_table(xls):
    import xlrd
    bk = xlrd.open_workbook(file_contents=xls)
    sh = bk.sheet_by_name('Data')
    head_rows = None
    for r in range(min(20, sh.nrows)):
        if any(str(c.value).strip() == 'Date' for c in sh.row(r)): head_rows = r
    if head_rows is None: raise ValueError('no "Date" header in sheet Data')
    labels = []
    for c in range(sh.ncols):        # join the header cells above (multi-row headers)
        parts = [str(sh.cell_value(r, c)).strip() for r in range(max(0, head_rows - 3), head_rows + 1)]
        labels.append(' '.join(p for p in parts if p))
    def col(*pats):
        for p in pats:
            for i, l in enumerate(labels):
                if re.search(p, l, re.I): return i
        raise ValueError(f'column {pats} not found in {labels}')
    C = {'date': col(r'(^| )Date$'), 'P': col(r'(^| )P$'), 'D': col(r'(^| )D$'), 'E': col(r'(^| )E$'),
         'gs10': col(r'GS10'), 'cape': col(r'(^| )CAPE$', r'P/E10'),
         'r10': col(r'10 Year Annualized Stock Real Return')}
    rows = []
    for r in range(head_rows + 1, sh.nrows):
        d = sh.cell_value(r, C['date'])
        if not isinstance(d, float): continue
        y, mo = int(d), int(round((d - int(d)) * 100))     # 1871.1 is October
        if not 1 <= mo <= 12: continue
        def num(name):
            v = sh.cell_value(r, C[name])
            return float(v) if isinstance(v, float) and v != '' else None
        rows.append({'y': y, 'm': mo, **{k: num(k) for k in ('P', 'D', 'E', 'gs10', 'cape', 'r10')}})
    return rows, labels

def val_cur(rows, upto):
    """cur = latest month with a CAPE (formulas checked against the existing VAL before use)."""
    rs = [r for r in rows if (r['y'], r['m']) <= upto and r['cape']]
    last = rs[-1]
    dy_row = [r for r in rs if r['D'] and r['P']][-1]
    cape = last['cape']
    ey = round(100 / cape, 2)
    gs10 = round(last['gs10'], 2) if last['gs10'] is not None else None
    return {'cape': round(cape, 1), 'ey': ey, 'dy': round(100 * dy_row['D'] / dy_row['P'], 2), 'gs10': gs10,
            'erp': round(ey - gs10, 2) if gs10 is not None else None, 'date': round(last['y'] + last['m'] / 100, 2)}

def ols(x, y):
    n = len(x); mx, my = sum(x) / n, sum(y) / n
    sxx = sum((a - mx) ** 2 for a in x); sxy = sum((a - mx) * (b - my) for a, b in zip(x, y))
    b = sxy / sxx; a = my - b * mx
    res = [yy - a - b * xx for xx, yy in zip(x, y)]
    sst = sum((yy - my) ** 2 for yy in y)
    return {'a': a, 'b': b, 'r2': 1 - sum(e * e for e in res) / sst, 'rsd': math.sqrt(sum(e * e for e in res) / (n - 2))}

REG_SPECS = {   # candidate definitions of the existing regression; only one that reproduces it is used
    'shiller_r10_on_ey_from1881': lambda rows, upto: [(1 / r['cape'], r['r10']) for r in rows
                                                       if r['y'] >= 1881 and (r['y'], r['m']) <= upto and r['cape'] and r['r10'] is not None],
    'shiller_r10_on_ey_all': lambda rows, upto: [(1 / r['cape'], r['r10']) for r in rows
                                                  if (r['y'], r['m']) <= upto and r['cape'] and r['r10'] is not None],
}

def reg_rounded(fit): return {'a': round(fit['a'], 4), 'b': round(fit['b'], 4), 'r2': round(fit['r2'], 3), 'rsd': round(fit['rsd'], 4)}

def rebuild_val(page, xls, R):
    V = page.val
    try: rows, labels = shiller_table(xls)
    except Exception as e: R.error(f'Shiller: cannot read ie_data.xls ({e!r}); VAL left as is'); return
    old_end = (int(V['cur']['date']), int(round((V['cur']['date'] % 1) * 100)))
    caped = [r for r in rows if r['y'] >= V['startYear'] and r['cape']]
    if (caped[0]['y'], caped[0]['m']) != (V['startYear'], 1): R.error('Shiller: CAPE no longer starts in January of startYear; VAL left as is'); return
    new_cape = [round(r['cape'], 2) for r in caped]
    n_old = len(V['cape'])
    changed = [i for i in range(min(n_old, len(new_cape))) if abs(new_cape[i] - V['cape'][i]) > 0.0051]
    # 1) cur: the formulas must give back the existing cur at the old end month
    redo = val_cur(rows, old_end)
    cur_ok = all(abs(redo[k] - V['cur'][k]) <= (0.051 if k == 'cape' else 0.011) for k in ('cape', 'ey', 'dy', 'gs10', 'erp')) and redo['date'] == V['cur']['date']
    if not cur_ok:
        R.error(f'Shiller: cur formulas do not reproduce the existing cur at {V["cur"]["date"]} '
                f'(got {redo}, have {V["cur"]}); VAL left as is'); return
    # 2) reg: refit only with a spec that reproduces the existing fit on data up to the old end month
    spec = None
    for name, f in REG_SPECS.items():
        pts = f(rows, old_end)
        if len(pts) > 30 and reg_rounded(ols([p[0] for p in pts], [p[1] for p in pts])) == V['reg']:
            spec = name; break
    if len(changed) > 24: R.note(f'Shiller: {len(changed)} historical CAPE values revised (first {1881 + changed[0] // 12}-{changed[0] % 12 + 1:02d})')
    V['cape'] = new_cape
    V['cur'] = val_cur(rows, (9999, 12))
    V['capeMean'] = round(statistics.median(new_cape), 1)
    if spec:
        pts = REG_SPECS[spec](rows, (9999, 12))
        V['reg'] = reg_rounded(ols([p[0] for p in pts], [p[1] for p in pts]))
        R.note(f'Shiller: reg reproduced with {spec}; refit on {len(pts)} months → {V["reg"]}')
    else:
        R.note('Shiller: could not reproduce the existing reg fit from ie_data.xls; reg left unchanged')
    R.row('Shiller', 'CAPE', 'monthly', f'{old_end[0]}-{old_end[1]:02d}',
          f'{int(V["cur"]["date"])}-{int(round(V["cur"]["date"] % 1 * 100)):02d}', len(new_cape),
          f'{len(changed)} of {n_old} old months revised; cur {V["cur"]}')

# --------------------------------------------------------------------------- report

def write_report(page, R, meta, path, policy, cap):
    ends = {k: v['d'][-1] for k, v in page.snap.items()}
    lo, hi = min(ends.values()), max(ends.values())
    L = [f'# Snapshot rebuild report', '', f'- fetched at: {meta["fetched_at"]}', f'- window policy: {policy}',
         f'- cap: {iso(cap) if cap else "none"}',
         f'- markets as of (oldest series end): **{iso(lo)}** (newest {iso(hi)}); '
         f'oldest: {", ".join(k for k, v in ends.items() if v == lo)}',
         f'- OHLC through {iso(max(v["d"][-1] for v in page.ohlc.values()))}',
         f'- FRED latest points: {iso(min(m["d"][-1] for m in page.macro.values()))} … {iso(max(m["d"][-1] for m in page.macro.values()))}',
         f'- CAPE through {page.val["cur"]["date"]}', '']
    if R.errors: L += ['## Errors', ''] + [f'- {e}' for e in R.errors] + ['']
    if R.notes: L += ['## Notes', ''] + [f'- {n}' for n in R.notes] + ['']
    L += ['## Series', '', '| source | id | rule | old end | new end | n | overlap check |', '|---|---|---|---|---|---|---|']
    L += ['| ' + ' | '.join(str(c) for c in r) + ' |' for r in R.rows]
    failed = [r for r in meta.get('requests', []) if not r.get('ok')]
    if failed: L += ['', '## Failed requests', ''] + [f'- `{r["url"]}` → {r["error"]}' for r in failed]
    with open(path, 'w', encoding='utf-8') as f: f.write('\n'.join(L) + '\n')

# --------------------------------------------------------------------------- roundtrip / selftest

def cmd_roundtrip(index):
    text = read_page(index)
    out = Page(text).render()
    if out == text: print(f'roundtrip OK: {len(text):,} bytes identical'); return True
    a, b = text.split('\n'), out.split('\n')
    for i, (x, y) in enumerate(zip(a, b)):
        if x != y:
            j = next(j for j in range(min(len(x), len(y))) if x[j] != y[j]) if x[:len(y)] != y[:len(x)] else min(len(x), len(y))
            print(f'roundtrip FAILED at line {i + 1}, col {j}: …{x[max(0, j - 60):j + 60]!r} vs …{y[max(0, j - 60):j + 60]!r}')
            return False
    print(f'roundtrip FAILED: line count {len(a)} vs {len(b)}'); return False

def fake_raw(page, rawdir):
    """Write the current snapshot as API-shaped responses (what each source would send if nothing changed)."""
    def w(rel, data):
        p = os.path.join(rawdir, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, 'w', encoding='utf-8') as f: f.write(data if isinstance(data, str) else json.dumps(data))
    last = max(v['d'][-1] for v in list(page.snap.values()) + list(page.ohlc.values()))
    fetched = dt.datetime.combine(date_of(last + 1), dt.time(23, 0), dt.timezone.utc)
    end_s = int(fetched.timestamp()) - 3 * 86400
    for k, (field, dec) in YAHOO_MODE.items():
        s = page.snap[k]; o = page.ohlc.get(k)
        close = dict(zip(s['d'], s['c']))
        opens = dict(zip(o['d'], o['o'])) if o else {}
        if o: close.update({d: c for d, c in zip(o['d'], o['c']) if d not in close})
        days = sorted(close)
        ts = [EPOCH_MS // 1000 + d * 86400 + 13 * 3600 + 1800 for d in days]   # 09:30 New York
        if field == 'close':
            q_close = [close[d] for d in days]; adj = [round(close[d] * 0.8, 6) for d in days]
        else:  # adjusted series: make unadjusted noticeably different so detection is exercised
            adj = [close[d] for d in days]; q_close = [round(close[d] * 1.3, 6) for d in days]
        w(f'yahoo/{k}.json', {'chart': {'error': None, 'result': [{
            'meta': {'symbol': YAHOO_SYMBOL.get(k, k), 'gmtoffset': -14400,
                     'currentTradingPeriod': {'regular': {'start': end_s - 23400, 'end': end_s}}},
            'timestamp': ts,
            'indicators': {'quote': [{'open': [opens.get(d, close[d]) for d in days], 'close': q_close}],
                           'adjclose': [{'adjclose': adj}]}}]}})
    for k, pair in CRYPTO.items():
        s = page.snap[k]
        rows = [[EPOCH_MS + d * 86400000, '0', '0', '0', f'{c:.8f}', '0', EPOCH_MS + (d + 1) * 86400000 - 1]
                for d, c in zip(s['d'], s['c'])]
        rows.append([EPOCH_MS + (last + 1) * 86400000, '0', '0', '0', '1.00000000', '0',
                     EPOCH_MS + (last + 2) * 86400000 - 1])     # an open candle that must be dropped
        for n in range(0, len(rows), 1000): w(f'binance/{pair}.{n // 1000:02d}.json', rows[n:n + 1000])
    fx = {}
    for k, code in FX.items():
        for d, c in zip(page.snap[k]['d'], page.snap[k]['c']): fx.setdefault(d, {})[code] = c
    ds = sorted(fx)
    for i in range(0, len(ds), 60):
        part = ds[i:i + 60]
        w(f'frankfurter/{iso(part[0])}.json', {'amount': 1.0, 'base': 'USD', 'start_date': iso(part[0]),
                                               'end_date': iso(part[-1]), 'rates': {iso(d): fx[d] for d in part}})
    for k, m in page.macro.items():
        lines = ['observation_date,' + k]
        sc = FRED_SCALE.get(k, 1)
        def fv(v):
            x = v * sc
            return str(int(x)) if x == int(x) and sc != 1 else repr(x)
        if k.startswith('BAML'):     # FRED serves only ~3 years of ICE data: rebuild must keep the older points
            pts = [(d, v) for d, v in zip(m['d'], m['v']) if d >= m['d'][-1] - 3 * 365]
        else: pts = list(zip(m['d'], m['v']))
        for i, (d, v) in enumerate(pts):
            lines.append(f'{iso(d)},{fv(v)}')
            if k in FRED_EVERY5 and i + 1 < len(pts):   # four valid days in between, plus a holiday blank
                lines += [f'{iso(d + j)},9.99' for j in range(1, 5)] + [f'{iso(d + 5)},']
        w(f'fred/{k}.csv', '\n'.join(lines) + '\n')
    w('meta.json', {'fetched_at': fetched.isoformat(), 'window': 'keep', 'requests': []})

def cmd_selftest(index, workdir):
    import tempfile
    page = Page(read_page(index)); check_rules(page)
    raw = tempfile.mkdtemp(prefix='raw_', dir=workdir)
    fake_raw(page, raw)
    out = os.path.join(workdir, 'selftest.html')
    print('rebuilding from fake responses (Yahoo, Binance, Frankfurter, FRED; Shiller absent) ...')
    rebuilt, R = cmd_rebuild(index, raw, out, clip_existing=True, quiet=True)
    orig = Page(read_page(index))
    problems = []
    for name in ('snap', 'ohlc', 'macro'):
        A, B = getattr(orig, name), getattr(rebuilt, name)
        for k in A:
            for f in A[k]:
                if A[k][f] != B[k][f]:
                    fld = 'v' if name == 'macro' else f
                    da, db = A[k]['d'], B[k]['d']
                    diffs = [(iso(d), x, y) for d, x, y in zip(da, A[k][f], B[k][f]) if x != y] if da == db and f != 'd' else 'dates differ'
                    problems.append((name.upper(), k, f, diffs if isinstance(diffs, str) else diffs[:3]))
    expected = [('OHLC', 'SPY', 'c')]   # last OHLC bar was an intraday 3-dp quote (744.284); 2-dp rounding cannot give it back
    unexpected = [p for p in problems if p[:3] not in expected]
    for p in problems: print('  diff:', p)
    errs = [e for e in R.errors if not e.startswith('Shiller')]
    for e in errs: print('  rebuild error:', e)
    ok = not unexpected and not errs and not any('changed 0' not in r[-1] and r[0] != 'Yahoo OHLC' for r in R.rows)
    if not ok:
        for r in R.rows:
            if 'changed 0' not in r[-1]: print('  row:', r)
    print('selftest', 'OK' if ok else 'FAILED', f'({len(R.rows)} series rebuilt, {len(problems)} diff(s), expected: {expected})')
    return ok

if __name__ == '__main__':
    a = sys.argv[1:]
    if not a: sys.exit(__doc__)
    flags = {x.split('=')[0]: (x.split('=', 1)[1] if '=' in x else True) for x in a if x.startswith('--')}
    a = [x for x in a if not x.startswith('--')]
    if a[0] == 'roundtrip': sys.exit(0 if cmd_roundtrip(a[1]) else 1)
    if a[0] == 'selftest': sys.exit(0 if cmd_selftest(a[1], flags.get('--workdir', os.path.dirname(os.path.abspath(__file__)))) else 1)
    if a[0] == 'fetch': cmd_fetch(a[1], a[2], flags.get('--window', 'keep'))
    elif a[0] == 'rebuild':
        _, R = cmd_rebuild(a[1], a[2], a[3], flags.get('--window'), flags.get('--cap'))
        sys.exit(1 if R.errors else 0)
    else: sys.exit(__doc__)
