import sys, os, tempfile, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import refresh_snapshot as rs
src, work = sys.argv[1], sys.argv[2]
full = rs.Page(rs.read_page(src))
raw = tempfile.mkdtemp(prefix='rawfull_', dir=work); rs.fake_raw(full, raw)
# unit checks for the two "in-progress bar" rules
j = json.load(open(f'{raw}/yahoo/SPY.json')); r = j['chart']['result'][0]
last_ts = r['timestamp'][-1]; r['meta']['currentTradingPeriod']['regular'] = {'start': last_ts, 'end': last_ts + 23400}
rows = rs.parse_yahoo(json.dumps(j).encode(), (last_ts + 3600) * 1000)
assert rs.iso(max(rows)) < '2026-06-22', 'partial Yahoo bar not dropped'
print('partial Yahoo bar dropped OK; last kept', rs.iso(max(rows)))
b = [open(f'{raw}/binance/{f}','rb').read() for f in sorted(os.listdir(f'{raw}/binance')) if f.startswith('BTCUSDT')]
meta = json.load(open(f'{raw}/meta.json')); import datetime as dt
fm = int(dt.datetime.fromisoformat(meta['fetched_at']).timestamp()*1000)
assert rs.iso(max(rs.parse_binance(b, fm))) == '2026-06-16', 'open Binance candle not dropped'
print('open Binance candle dropped OK')
# truncate: drop the last 15 points of every market series and the last 4 of every FRED series
t = rs.Page(rs.read_page(src))
for o in (t.snap, t.ohlc):
    for v in o.values():
        for f in [k for k in v if k in ('d','o','c')]: v[f] = v[f][:-15]
for m in t.macro.values(): m['d'], m['v'] = m['d'][:-4], m['v'][:-4]
tp = os.path.join(work, 'truncated.html'); open(tp, 'w', encoding='utf-8', newline='').write(t.render())
out = os.path.join(work, 'appended.html')
reb, R = rs.cmd_rebuild(tp, raw, out, quiet=True)
bad = 0
for name in ('snap','ohlc','macro'):
    A, B = getattr(full, name), getattr(reb, name)
    for k in A:
        a, b = A[k], B[k]
        f = 'v' if name == 'macro' else 'c'
        ma, mb = dict(zip(a['d'], a[f])), dict(zip(b['d'], b[f]))
        lost = sorted(set(ma) - set(mb)); gained = sorted(set(mb) - set(ma))
        changed = [(rs.iso(d), ma[d], mb[d]) for d in ma if d in mb and ma[d] != mb[d]]
        if lost or gained or changed:
            bad += 1
            print(f'{name.upper():5s} {k:13s} lost {len(lost)} gained {[rs.iso(d) for d in gained][:6]} changed {changed[:2]}')
print('errors:', R.errors)
print('series with differences:', bad)
