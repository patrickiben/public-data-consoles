"""Line diff of every card's text between two verify.mjs dumps: shows each figure that moved.
usage: python3 -I carddiff.py before.json after.json"""
import difflib, json, sys
a, b = (json.load(open(p)) for p in sys.argv[1:3])
for k in ('pill', 'dataHealth', 'regime'):
    if a.get(k) != b.get(k): print(f'== {k}\n  - {a.get(k)!r}\n  + {b.get(k)!r}')
for title in a['cards'].keys() | b['cards'].keys():
    x, y = a['cards'].get(title, '').splitlines(), b['cards'].get(title, '').splitlines()
    d = [l for l in difflib.unified_diff(x, y, lineterm='', n=1) if not l.startswith(('---', '+++'))]
    if d: print(f'== {title}'); print('\n'.join('  ' + l[:220] for l in d))
